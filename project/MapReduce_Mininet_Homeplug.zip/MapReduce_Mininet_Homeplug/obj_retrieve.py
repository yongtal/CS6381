#!/usr/bin/env python
#
# Institution: Vanderbilt University
# Code created for the CS4287-5287 course
# Author: Aniruddha Gokhale
# Created: Fall 2016
#
# The purpose of this code is to access the huge file we have uploaded to the
# Horizon cloud container storage

# import the system basic files
import os
import sys
import time

# import the openstack swift project
from swiftclient import client
from mr_thread import MR_Thread
# from hurry.filesize import size

# http://docs.openstack.org/developer/python-swiftclient/swiftclient.html#module-swiftclient.client

#--------------------------------------------------------------------------
# The assumption below is that we have sourced our openrc file
#
# get our credentials from the environment variables. Note that we
# use the same names for the indexes as those needed by the parameters
# in the swift client connection request.
#
# Note, this is slightly different from the nova credentials but nonetheless
# both use authentication against the keystone URL
def get_swift_creds ():
    d = {}
    # These are obtained from our environment. Don't forget
    # to do "source cloudclass-rc.sh" or whatever is the name of your rc file
    #
    d['authurl'] = os.environ['OS_AUTH_URL']
    d['user'] = os.environ['OS_USERNAME']
    d['key'] = os.environ['OS_PASSWORD']
    d['tenant_name'] = os.environ['OS_TENANT_NAME']
    d['auth_version'] = '2.0'  # because we will be using the version 2 of the API
    #d['tenant_id'] = os.environ['OS_TENANT_ID']
    #d['region_name'] = os.environ['OS_REGION_NAME']
#    print d
    return d

#----------------------------------------------------------------------------
# create a connection to the cloud using our credentials. We need this during
# container access
def create_connection (creds):
    # Now access the connection from which everything else is obtained.
    try:
        conn = client.Connection (**creds)
    except:
        print "Exception thrown: ", sys.exc_info()[0]
        raise

    return conn


#------------------------------------------------------------------------
# retrieve an object from the container
#
def retrieve_object (conn, cont_name, obj_name):
    try:
        # respdict = {}
    # response_dict=respdict
    #resp_chunk_size=1024
        obj_tuple = conn.get_object(cont_name, obj_name, resp_chunk_size=11322901)

        # this is for debugging only to get the metadata of the object
#        print "Response dictionary = ", respdict
        
    except:
        print "Exception thrown: ", sys.exc_info()[0]
        raise

    return obj_tuple

#------------------------------------------------------------------------
# main function
#
def main ():

    #global obj_tuple
    print "Main function: get credentials"
    creds = get_swift_creds()
    
    print "Main function: establish connection to horizon cloud"
    conn = create_connection (creds)
    
    print "Main function: retrieve object within the container storage"
    # In reality we need to retrieve this object but for demo purposes,
    # we are retrieving a relatively smaller text file
    for i in range(1):  # 1 for demo; should 300
        #obj_tuple = retrieve_object (conn, "CloudClassSmartHome", "big.txt")
        obj_tuple = retrieve_object (conn, "CloudClassSmartHome", "energy-sorted100M.csv")
        print "Main function: success retrieving the object"

        # obj_tuple[1] is a string
        # Write string into a file to try to reuse more parts of professor's code
        fileName = "Segment" + str(i)
        seg_file = open(fileName + ".csv", "w")
        seg_file.write(obj_tuple[1].read(11322901))
        seg_file.write('\n')
        seg_file.close()

    print "Content length = ", obj_tuple[0]['content-length']
    print "Retrieve work finished"

#------------------------------------------------------------------------
# invoke main
if __name__ == "__main__":
    sys.exit (main ())
    
